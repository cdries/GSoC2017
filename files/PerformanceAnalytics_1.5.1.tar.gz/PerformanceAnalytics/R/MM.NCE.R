###############################################################################
# Functions to compute the Nearest Comoment Estimator.
#
# Copyright (c) 2008 Kris Boudt and Brian G. Peterson
# Copyright (c) 2004-2015 Peter Carl and Brian G. Peterson for PerformanceAnalytics
# This R package is distributed under the terms of the GNU Public License (GPL)
# for full details see the file COPYING
###############################################################################
# $Id$
###############################################################################

### build objective function with gradient
NCE_obj <- function(theta, p, k, W, m2, m3, m4, include.mom, B, epsvar, fskew, epsskew, fkurt, epskurt) {
  
  # model parameters
  nd <- 0
  if (is.null(B)) {
    Binclude <- 1
    B <- matrix(theta[(nd + 1):(nd + p * k)], ncol = k)
    nd <- nd + p * k
  } else {
    Binclude <- 0
  }
  if (is.null(epsvar) & (include.mom[1] | include.mom[3])) {
    epsvarinclude <- 1
    epsvar <- theta[(nd + 1):(nd + p)]
    nd <- nd + p
  } else {
    epsvarinclude <- 0
  }
  if (is.null(fskew) & include.mom[2]) {
    fskewinclude <- 1
    fskew <- theta[(nd + 1):(nd + k)]
    nd <- nd + k
  } else {
    fskewinclude <- 0
  }
  if (is.null(epsskew) & include.mom[2]) {
    epsskewinclude <- 1
    epsskew <- theta[(nd + 1):(nd + p)]
    nd <- nd + p
  } else {
    epsskewinclude <- 0
  }
  if (is.null(fkurt) & include.mom[3]) {
    fkurtinclude <- 1
    fkurt <- theta[(nd + 1):(nd + k)]
    nd <- nd + k
  } else {
    fkurtinclude <- 0
  }
  if (is.null(epskurt) & include.mom[3]) {
    epskurtinclude <- 1
    epskurt <- theta[(nd + 1):(nd + p)]
  } else {
    epskurtinclude <- 0
  }
  
  # model moments
  if (include.mom[1]) {
    mod2 <- B %*% t(B) + diag(epsvar)
    mod2 <- mod2[lower.tri(diag(p), diag = TRUE)]
  } else {
    mod2 <- NULL
  }
  if (include.mom[2]) {
    mod3 <- .Call('M3_T23', fskew, k, PACKAGE="PerformanceAnalytics")
    mod3 <- .Call('M3timesFull', mod3, as.numeric(B), k, p, PACKAGE="PerformanceAnalytics")
    mod3 <- mod3 + .Call('M3_T23', epsskew, p, PACKAGE="PerformanceAnalytics")
  } else {
    mod3 <- NULL
  }
  if (include.mom[3]) {
    mod4 <- .Call('M4_T12', fkurt, rep(1, k), k, PACKAGE="PerformanceAnalytics")
    mod4 <- .Call('M4timesFull', mod4, as.numeric(B), k, p, PACKAGE="PerformanceAnalytics")
    Stransf <- B %*% t(B)
    mod4 <- mod4 + .Call('M4_MFresid', as.numeric(Stransf), epsvar, p, PACKAGE="PerformanceAnalytics")
    mod4 <- mod4 + .Call('M4_T12', epskurt, epsvar, p, PACKAGE="PerformanceAnalytics")
  } else {
    mod4 <- NULL
  }
  
  nelem_mom <- c(p * (p + 1) / 2, p * (p + 1) * (p + 2) / 6, p * (p + 1) * (p + 2) * (p + 3) / 24)
  ### calculate objective value
  if (NCOL(W) == 1) {
    # case of diagonal W matrix
    nd <- 0
    objval <- 0
    if (include.mom[1]) {
      mdiff2w <- (m2 - mod2) * W[(nd + 1):(nd + nelem_mom[1])]
      objval <- objval + sum(mdiff2w * (m2 - mod2))
      nd <- nd + nelem_mom[1]
    }
    if (include.mom[2]) {
      mdiff3w <- (m3 - mod3) * W[(nd + 1):(nd + nelem_mom[2])]
      objval <- objval + sum(mdiff3w * (m3 - mod3))
      nd <- nd + nelem_mom[2]
    }
    if (include.mom[3]) {
      mdiff4w <- (m4 - mod4) * W[(nd + 1):(nd + nelem_mom[3])]
      objval <- objval + sum(mdiff4w * (m4 - mod4))
    }
  } else {
    # case of full W matrix
    momdiff <- c(m2 - mod2, m3 - mod3, m4 - mod4)
    mdiffw <- W %*% momdiff
    objval <- sum(momdiff * mdiffw)
    nd <- 0
    if (include.mom[1]) {
      mdiff2w <- mdiffw[(nd + 1):(nd + nelem_mom[1])]
      nd <- nd + nelem_mom[1]
    }
    if (include.mom[2]) {
      mdiff3w <- mdiffw[(nd + 1):(nd + nelem_mom[2])]
      nd <- nd + nelem_mom[2]
    }
    if (include.mom[3]) {
      mdiff4w <- mdiffw[(nd + 1):(nd + nelem_mom[3])]
    }
  }
  
  ### calculate gradient
  if (include.mom[1]) {
    grad2 <- .Call('mod2grad', p, k, as.numeric(B), Binclude, epsvarinclude, PACKAGE="PerformanceAnalytics") %*% mdiff2w
    grad2 <- c(grad2, rep(0, length(theta) - length(grad2)))
  } else {
    grad2 <- rep(0, length(theta))
  }
  if (include.mom[2]) {
    grad3 <- .Call('mod3grad', p, k, as.numeric(B), Binclude, epsvarinclude,
                   fskew, fskewinclude, epsskewinclude, PACKAGE="PerformanceAnalytics") %*% mdiff3w
    grad3 <- c(grad3, rep(0, length(theta) - length(grad3)))
  } else {
    grad3 <- rep(0, length(theta))
  }
  if (include.mom[3]) {
    grad4 <- .Call('mod4grad', p, k, as.numeric(B), Binclude, epsvarinclude, epsvar,
                   fskewinclude, epsskewinclude, fkurt, fkurtinclude,
                   epskurt, epskurtinclude, PACKAGE="PerformanceAnalytics") %*% mdiff4w
  } else {
    grad4 <- rep(0, length(theta))
  }
  
  grad <- -2 * (grad2 + grad3 + grad4)
  
  return ( list("objective" = objval, "gradient" = grad) )
}


### build objective function without gradient
NCE_objDE <- function(theta, p, k, W, m2, m3, m4, include.mom, B, epsvar, fskew, epsskew, fkurt, epskurt, include.ineq) {
  
  objval <- NCE_obj(theta, p, k, W, m2, m3, m4, include.mom, B, epsvar, fskew, epsskew, fkurt, epskurt)$objective
  
  if (include.ineq) {
    ineq <- NCE_obj_ineq(theta, p, k, W, m2, m3, m4, include.mom, B, epsvar, fskew, epsskew, fkurt, epskurt)$constraints
    if (max(ineq) > 1e-10) objval <- objval + 1e10
  }
  
  return ( objval )
}

### build objective function gradient
NCE_objDE_grad <- function(theta, p, k, W, m2, m3, m4, include.mom, B, epsvar, fskew, epsskew, fkurt, epskurt, include.ineq) {
  
  grad <- NCE_obj(theta, p, k, W, m2, m3, m4, include.mom, B, epsvar, fskew, epsskew, fkurt, epskurt)$gradient
  
  return ( grad )
}



NCE_obj_ineq <- function(theta, p, k, W, m2, m3, m4, include.mom, B, epsvar, fskew, epsskew, fkurt, epskurt) {
  
  # model parameters
  nd <- 0
  if (is.null(B)) {
    Binclude <- 1
    B <- matrix(theta[(nd + 1):(nd + p * k)], ncol = k)
    nd <- nd + p * k
  } else {
    Binclude <- 0
  }
  if (is.null(epsvar) & (include.mom[1] | include.mom[3])) {
    epsvarinclude <- 1
    epsvar <- theta[(nd + 1):(nd + p)]
    nd <- nd + p
  } else {
    epsvarinclude <- 0
  }
  if (is.null(fskew) & include.mom[2]) {
    fskewinclude <- 1
    fskew <- theta[(nd + 1):(nd + k)]
    nd <- nd + k
  } else {
    fskewinclude <- 0
  }
  if (is.null(epsskew) & include.mom[2]) {
    epsskewinclude <- 1
    epsskew <- theta[(nd + 1):(nd + p)]
    nd <- nd + p
  } else {
    epsskewinclude <- 0
  }
  if (is.null(fkurt) & include.mom[3]) {
    fkurtinclude <- 1
    fkurt <- theta[(nd + 1):(nd + k)]
    nd <- nd + k
  } else {
    fkurtinclude <- 0
  }
  if (is.null(epskurt) & include.mom[3]) {
    epskurtinclude <- 1
    epskurt <- theta[(nd + 1):(nd + p)]
  } else {
    epskurtinclude <- 0
  }
  
  ### compute inequalities
  fineq <- fskew^2 + 1 - fkurt
  epsineq <- epsskew^2 / epsvar^3 + 1 - epskurt / epsvar^2
  objineq <- c(fineq, epsineq)
  
  ### compute gradient
  grad <- matrix(0, nrow = p + k, ncol = length(theta))
  nd <- 0
  if (Binclude) nd <- p * k
  if (include.mom[1] & epsvarinclude) {
    for (ii in 1:p) grad[k + ii, nd + ii] <- -3 * epsskew[ii]^2 / epsvar[ii]^4 + 2 * epskurt[ii] / epsvar[ii]^3
    nd <- nd + p
  }
  if (include.mom[2]) {
    if (fskewinclude) {
      for (ii in 1:k) grad[ii, nd + ii] <- 2 * fskew[ii]
      nd <- nd + k
    }
    if (epsskewinclude) {
      for (ii in 1:p) grad[k + ii, nd + ii] <- 2 * epsskew[ii] / epsvar[ii]^3
      nd <- nd + p
    }
  }
  if (include.mom[3]) {
    if (fkurtinclude) {
      for (ii in 1:k) grad[ii, nd + ii] <- -1
      nd <- nd + k
    }
    if (epskurtinclude) {
      for (ii in 1:p) grad[k + ii, nd + ii] <- -1 / epsvar[ii]^2
    }
  }
  
  return ( list("constraints" = objineq, "jacobian" = grad) )
}


#' Functions for calculating the nearest comoment estimator for financial time series
#' 
#' calculates NCE covariance, coskewness and cokurtosis matrices
#' 
#' The coskewness and cokurtosis matrices are defined as the matrices of dimension 
#' p x p^2 and p x p^3 containing the third and fourth order central moments. They
#' are useful for measuring nonlinear dependence between different assets of the 
#' portfolio and computing modified VaR and modified ES of a portfolio.
#' 
#' The nearest comoment estimator is a way to estimate the covariance, coskewness and
#' cokurtosis matrix by means of a latent multi-factor model. The method is proposed in 
#' CITE TODO.
#' @name NCE
#' @concept co-moments
#' @concept moments
#' @aliases NCE MM.NCE
#' @param R an xts, vector, matrix, data frame, timeSeries or zoo object of
#' asset returns (with mean zero)
#' @param include.mom select to compute covariance, coskewness or cokurtosis matrix
#' @param as.mat TRUE/FALSE whether to return the full moment matrix or only
#' the vector with the unique elements (the latter is advised for speed), default
#' TRUE
#' @param \dots any other passthru parameters
#' @author Dries Cornilly
#' @seealso \code{\link{CoMoments}} \cr \code{\link{ShrinkageMoments}} \cr \code{\link{StructuredMoments}}  
#' \cr \code{\link{EWMAMoments}} \cr \code{\link{MCA}}
#' @references 
#' TODO
###keywords ts multivariate distribution models
#' @examples
#' 
#' data(edhec)
#' 
#' # EWMA estimation
#' # 'as.mat = F' would speed up calculations in higher dimensions
#' sigma <- M2.ewma(edhec, 0.94)
#' m3 <- M3.ewma(edhec, 0.94)
#' m4 <- M4.ewma(edhec, 0.94)
#' 
#' # compute equal-weighted portfolio modified ES 
#' mu <- colMeans(edhec)
#' p <- length(mu)
#' ES(p = 0.95, portfolio_method = "component", weights = rep(1 / p, p), mu = mu, 
#'     sigma = sigma, m3 = m3, m4 = m4)
#' 
#' # compare to sample method
#' sigma <- cov(edhec)
#' m3 <- M3.MM(edhec)
#' m4 <- M4.MM(edhec)
#' ES(p = 0.95, portfolio_method = "component", weights = rep(1 / p, p), mu = mu, 
#'     sigma = sigma, m3 = m3, m4 = m4)
#' 
#' @export MM.NCE
MM.NCE <- function(R, include.mom = c(TRUE, TRUE, TRUE), as.mat = TRUE, ...) {
  # @author Dries Cornilly
  #
  # DESCRIPTION:
  # computes the nearest comoment estimators as in Boudt, Cornilly and Verdonck (2017)
  #
  # Inputs:
  # R         : numeric matrix of dimensions NN x PP
  # include.mom : select to compute covariance, coskewness or cokurtosis matrix
  # as.mat    : output as a matrix or as the vector with only unique coskewness eleements
  #
  # Outputs:
  # M2nce     : NCE covariance matrix
  # M3nce     : NCE coskewness matrix
  # M4nce     : NCE cokurtosis matrix
  # optim_sol ; output of the optimizer
  
  x <- coredata(R)
  n <- nrow(x)
  p <- ncol(x)
  
  ### set number of factors to use
  if (hasArg(k)) k <- list(...)$k else k <- 1
  
  ### compute initial estimators, if necessary
  if (hasArg(m2)) {
    m2 <- list(...)$m2
  } else {
    if (include.mom[1]) m2 <- cov(x)[lower.tri(diag(p), diag = TRUE)] * (n - 1) / n else m2 <- NULL
  }
  if (hasArg(m3)) {
    m3 <- list(...)$m3
  } else {
    if (include.mom[2]) m3 <- M3.MM(x, as.mat = FALSE) else m3 <- NULL
  }
  if (hasArg(m4)) {
    m4 <- list(...)$m4
  } else {
    if (include.mom[3]) m4 <- M4.MM(x, as.mat = FALSE) else m4 <- NULL
  }
  
  ### buil W matrix, if necessary
  nelem_mom <- c(p * (p + 1) / 2, p * (p + 1) * (p + 2) / 6, p * (p + 1) * (p + 2) * (p + 3) / 24)
  nelem <- sum(include.mom * nelem_mom)
  if (hasArg(W)) W <- list(...)$W else W <- rep(1, nelem)
  
  ### prepare model parameters
  if (hasArg(B)) B <- list(...)$B else B <- NULL
  if (hasArg(epsvar)) epsvar <- list(...)$epsvar else epsvar <- NULL
  if (hasArg(fskew)) fskew <- list(...)$fskew else fskew <- NULL
  if (hasArg(epsskew)) epsskew <- list(...)$epsskew else epsskew <- NULL
  if (hasArg(fkurt)) fkurt <- list(...)$fkurt else fkurt <- NULL
  if (hasArg(epskurt)) epskurt <- list(...)$epskurt else epskurt <- NULL
  
  ### initial estimate
  if (hasArg(x0)) {
    x0 <- list(...)$x0
  } else {
    x0list <- NCEinitialPCA(x, k)
    x0 <- NULL
    if (is.null(B)) x0 <- c(x0, x0list$x0list$B)
    if (is.null(epsvar) & (include.mom[1] | include.mom[3])) x0 <- c(x0, x0list$x0list$Deltadiag)
    if (is.null(fskew) & include.mom[2]) x0 <- c(x0, x0list$x0list$Gmarg)
    if (is.null(epsskew) & include.mom[2]) x0 <- c(x0, x0list$x0list$Omarg)
    if (is.null(fkurt) & include.mom[3]) x0 <- c(x0, x0list$x0list$Pmarg)
    if (is.null(epskurt) & include.mom[3]) x0 <- c(x0, x0list$x0list$GGmarg)
  }
  
  ### fit the model
  if (hasArg(optimize_method)) optimize_method <- list(...)$optimize_method else optimize_method <- "nloptr"
  if (hasArg(include.ineq)) include.ineq <- list(...)$include.ineq else include.ineq <- TRUE
  if (hasArg(optscontrol)) {
    optscontrol <- list(...)$optscontrol
  } else {
    optscontrol <- list(algorithm = "NLOPT_LD_MMA", xtol_rel = 1e-05, 
                        ftol_rel = 1e-05, ftol_abs = 1e-05, maxeval = 1000, print_level = 0,
                        check_derivatives = FALSE)
  }
  lowerbound <- NULL
  if (is.null(B)) lowerbound <- c(lowerbound, rep(-Inf, p * k))
  if (is.null(epsvar) & (include.mom[1] | include.mom[3])) lowerbound <- c(lowerbound, rep(1e-10, p))
  if (is.null(fskew) & include.mom[2]) lowerbound <- c(lowerbound, rep(-Inf, k))
  if (is.null(epsskew) & include.mom[2]) lowerbound <- c(lowerbound, rep(-Inf, p))
  if (is.null(fkurt) & include.mom[3]) lowerbound <- c(lowerbound, rep(1e-10, k))
  if (is.null(epskurt) & include.mom[3]) lowerbound <- c(lowerbound, rep(1e-16, p))
  upperbound <- rep(Inf, length(lowerbound))
  
  if (optimize_method == "nloptr") {
    stopifnot("package:nloptr" %in% search() || requireNamespace("nloptr", quietly = TRUE))
    
    if (include.ineq) {
      sol <- nloptr::nloptr(x0 = x0, eval_f = NCE_obj, eval_g_ineq = NCE_obj_ineq,
                            lb = lowerbound, ub = upperbound, opts = optscontrol,
                            p = p, k = k, W = W, m2 = m2, m3 = m3, m4 = m4,
                            include.mom = include.mom, B = B, epsvar = epsvar, fskew = fskew,
                            epsskew = epsskew, fkurt = fkurt, epskurt = epskurt)
    } else {
      sol <- nloptr::nloptr(x0 = x0, eval_f = NCE_obj, lb = lowerbound, ub = upperbound,
                            opts = optscontrol, p = p, k = k, W = W, m2 = m2, m3 = m3, m4 = m4,
                            include.mom = include.mom, B = B, epsvar = epsvar, fskew = fskew,
                            epsskew = epsskew, fkurt = fkurt, epskurt = epskurt)
    }
    theta <- sol$solution
  } else if (optimize_method == "genoud") {
    ubM2 <- max(colMeans((x - matrix(colMeans(x), nrow = n, ncol = p, byrow = TRUE))^2)) # max of marginal variances of observations
    ubM3 <- max(abs(colMeans((x - matrix(colMeans(x), nrow = n, ncol = p, byrow = TRUE))^3))) # max of marginal variances of observations
    ubM4 <- max(abs(colMeans((x - matrix(colMeans(x), nrow = n, ncol = p, byrow = TRUE))^4))) # max of marginal variances of observations
    lowerbound2 <- NULL
    upperbound2 <- NULL
    if (is.null(B)) {
      lowerbound2 <- c(lowerbound2, rep(-sqrt(1.1 * ubM2), p * k))
      upperbound2 <- c(upperbound2, rep(sqrt(1.1 * ubM2), p * k))
    }
    if (is.null(epsvar) & (include.mom[1] | include.mom[3])) {
      lowerbound2 <- c(lowerbound2, rep(1e-10, p))
      upperbound2 <- c(upperbound2, rep(1.1 * ubM2, p))
    }
    if (is.null(fskew) & include.mom[2]) {
      lowerbound2 <- c(lowerbound2, rep(-3, k))
      upperbound2 <- c(upperbound2, rep(3, k))
    }
    if (is.null(epsskew) & include.mom[2]) {
      lowerbound2 <- c(lowerbound2, rep(-1.1 * ubM3 - 3 * k * (sqrt(1.1 * ubM2))^3 , p))
      upperbound2 <- c(upperbound2, rep(1.1 * ubM3 + 3 * k * (sqrt(1.1 * ubM2))^3 , p))
    }
    if (is.null(fkurt) & include.mom[3]) {
      lowerbound2 <- c(lowerbound2, rep(1e-10, k))
      upperbound2 <- c(upperbound2, rep(25, k))
    }
    if (is.null(epskurt) & include.mom[3]) {
      lowerbound2 <- c(lowerbound2, rep(1e-16, p))
      upperbound2 <- c(upperbound2, rep(1.1 * ubM4, p))
    }
    nvars <- length(lowerbound)
    stopifnot("package:rgenoud" %in% search() || requireNamespace("rgenoud", quietly = TRUE))
    options(warn = -1)
    sol <- rgenoud::genoud(fn = NCE_objDE, nvars = nvars, max = FALSE, pop.size = 500,
                           max.generations = 25, wait.generations = 5, hard.generation.limit = TRUE,
                           starting.values = x0, MemoryMatrix = TRUE, Domains = cbind(lowerbound2, upperbound2),
                           solution.tolerance = 0.00075, gr = NCE_objDE_grad,
                           boundary.enforcement = 2, lexical = FALSE, gradient.check = TRUE,
                           BFGS = TRUE, data.type.int = FALSE, hessian = FALSE,
                           unif.seed = 812821, int.seed = 53058, print.level = 0, share.type = 0,
                           instance.number = 0, output.path = "stdout", output.append = FALSE, project.path = NULL,
                           P1 = 50, P2 = 50, P3 = 50, P4 = 50, P5 = 50, P6 = 50, P7 = 50, P8 = 50, P9 = 0,
                           P9mix = NULL, BFGSburnin = 0, BFGSfn = NULL, BFGShelp = NULL,
                           control = list(),
                           optim.method = "L-BFGS-B", transform = FALSE, debug = FALSE, cluster = FALSE, balance = FALSE,
                           p = p, k = k, W = W, m2 = m2, m3 = m3, m4 = m4, include.mom = include.mom, B = B,
                           epsvar = epsvar, fskew = fskew, epsskew = epsskew, fkurt = fkurt, epskurt = epskurt,
                           include.ineq = include.ineq)
    options(warn = 0)
    if (include.ineq) {
      sol <- nloptr::nloptr(x0 = sol$par, eval_f = NCE_obj, eval_g_ineq = NCE_obj_ineq,
                            lb = lowerbound, ub = upperbound, opts = optscontrol,
                            p = p, k = k, W = W, m2 = m2, m3 = m3, m4 = m4,
                            include.mom = include.mom, B = B, epsvar = epsvar, fskew = fskew,
                            epsskew = epsskew, fkurt = fkurt, epskurt = epskurt)
    } else {
      sol <- nloptr::nloptr(x0 = sol$par, eval_f = NCE_obj, lb = lowerbound, ub = upperbound,
                            opts = optscontrol, p = p, k = k, W = W, m2 = m2, m3 = m3, m4 = m4,
                            include.mom = include.mom, B = B, epsvar = epsvar, fskew = fskew,
                            epsskew = epsskew, fkurt = fkurt, epskurt = epskurt)
    }
    theta <- sol$solution
  }
  
  ### construct the moment estimates
  nd <- 0
  if (is.null(B)) {
    B <- matrix(theta[(nd + 1):(nd + p * k)], ncol = k)
    nd <- nd + p * k
  }
  if (is.null(epsvar) & (include.mom[1] | include.mom[3])) {
    epsvar <- theta[(nd + 1):(nd + p)]
    nd <- nd + p
  }
  if (is.null(fskew) & include.mom[2]) {
    fskew <- theta[(nd + 1):(nd + k)]
    nd <- nd + k
  }
  if (is.null(epsskew) & include.mom[2]) {
    epsskew <- theta[(nd + 1):(nd + p)]
    nd <- nd + p
  }
  if (is.null(fkurt) & include.mom[3]) {
    fkurt <- theta[(nd + 1):(nd + k)]
    nd <- nd + k
  }
  if (is.null(epskurt) & include.mom[3]) {
    epskurt <- theta[(nd + 1):(nd + p)]
  }
  
  if (include.mom[1]) {
    mod2 <- B %*% t(B) + diag(epsvar)
  } else {
    mod2 <- NULL
  }
  if (include.mom[2]) {
    mod3 <- .Call('M3_T23', fskew, k, PACKAGE="PerformanceAnalytics")
    mod3 <- .Call('M3timesFull', mod3, as.numeric(B), k, p, PACKAGE="PerformanceAnalytics")
    mod3 <- mod3 + .Call('M3_T23', epsskew, p, PACKAGE="PerformanceAnalytics")
    if (as.mat) mod3 <- M3.vec2mat(mod3, p)
  } else {
    mod3 <- NULL
  }
  if (include.mom[3]) {
    mod4 <- .Call('M4_T12', fkurt, rep(1, k), k, PACKAGE="PerformanceAnalytics")
    mod4 <- .Call('M4timesFull', mod4, as.numeric(B), k, p, PACKAGE="PerformanceAnalytics")
    Stransf <- B %*% t(B)
    mod4 <- mod4 + .Call('M4_MFresid', as.numeric(Stransf), epsvar, p, PACKAGE="PerformanceAnalytics")
    mod4 <- mod4 + .Call('M4_T12', epskurt, epsvar, p, PACKAGE="PerformanceAnalytics")
    if (as.mat) mod4 <- M4.vec2mat(mod4, p)
  } else {
    mod4 <- NULL
  }
  
  return ( list("M2nce" = mod2, "M3nce" = mod3, "M4nce" = mod4, "optim_sol" = sol) )
}


NCEinitialPCA <- function (x, k) {
  ### Computes initial starting values for the NCE algorithm based on PCA
  # x: data matrix, columns are dimension, each row is a new observation
  # k: number of factors to use
  
  n <- dim(x)[1]                                                      # number of observations
  p <- dim(x)[2]                                                      # number of dimensions
  
  x <- x - matrix(colMeans(x), nrow = n, ncol = p, byrow = TRUE)      # center the data
  pca <- princomp(x, cor = FALSE, scores = k)                         # compute PCA
  
  x0list <- list()                                                    # initialize list of starting values
  f <- pca$scores[, 1:k]                                              # compute factor estimates
  if (k == 1) f <- matrix(f, ncol = 1)
  sdf <- sqrt(apply(f, 2, var))                                       # to normalize f and B
  f <- f / matrix(sdf, nrow = n, ncol = k, byrow = TRUE)              # normalized f
  x0list$B <- as.matrix(pca$loadings[, 1:k]) * matrix(sdf, nrow = p, ncol = k, byrow = TRUE) # list the B matrix
  eps <- x - f %*% t(x0list$B)                                        # compute residual term
  
  x0list$Deltadiag <- apply(eps, 2, var)                              # list marginal variances of eps
  x0list$Gmarg <- apply(f, 2, function(a) sum((a - mean(a))^3) * n / ((n - 1) * (n - 2))) # list marginal skewness of factors
  x0list$Omarg <- apply(eps, 2, function(a) sum((a - mean(a))^3) * n / ((n - 1) * (n - 2))) # list marginal skewness of eps
  
  x0list$Pmarg <- apply(f, 2, function(a) sum((a - mean(a))^4) / n)   # list marginal kurtosis of factors
  x0list$GGmarg <- apply(eps, 2, function(a) sum((a - mean(a))^4) / n) # list marginal kurtosis of eps
  
  x0 <- c(c(x0list$B), x0list$Deltadiag, x0list$Gmarg, x0list$Omarg, x0list$Pmarg, x0list$GGmarg)
  
  return ( list("x0list" = x0list, "x0" = x0, "f" = f) )
}


NCEconstructW <- function (X, Wnum, include.mom = c(T, T, T), Xi = FALSE) {
  
  nelem_mom <- c(p * (p + 1) / 2, p * (p + 1) * (p + 2) / 6, p * (p + 1) * (p + 2) * (p + 3) / 24)
  nelem <- sum(include.mom * nelem_mom)
  
  n <- nrow(X)
  p <- ncol(X)
  Xc <- X - matrix(colMeans(X), nrow = n, ncol = p, byrow = TRUE)
  Xc2 <- Xc^2
  m11 <- t(Xc) %*% Xc / n
  m22 <- t(Xc2) %*% Xc2 / n
  
  
  # equal-weighted weight matrix
  if (Wnum == 1) W <- rep(1, nelem)
  
  # inverse-variance weighted - diagonal
  iter <- 1
  if (Wnum == 2) {
    W <- rep(NA, nelem)
    
    # covariance elements
    if (include.mom[1]) {
      for (ii in 1:p) {
        for (jj in ii:p) {
          W[iter] <- m22[ii, jj] - m11[ii, jj]^2
          iter <- iter + 1
        }
      }
    }
    
    # coskewness elements
    if (include.mom[2]) {
      for (ii in 1:p) {
        for (jj in ii:p) {
          for (kk in jj:p) {
            c011 <- m11[jj, kk]
            c101 <- m11[ii, kk]
            c110 <- m11[ii, jj]
            c211 <- mean(Xc2[, ii] * Xc[, jj] * Xc[, kk])
            c121 <- mean(Xc[, ii] * Xc2[, jj] * Xc[, kk])
            c112 <- mean(Xc[, ii] * Xc[, jj] * Xc2[, kk])
            W[iter] <- mean(Xc2[, ii] * Xc2[, jj] * Xc2[, kk]) - mean(Xc[, ii] * Xc[, jj] * Xc[, kk])^2 -
              2 * c011 * c211 - 2 * c101 * c121 - 2 * c110 * c112 +
              c011 * m11[ii, ii] + c101 * m11[jj, jj] + c110 * m11[kk, kk] + 6 * c011 * c101 * c110
            iter <- iter + 1
          }
        }
      }
    }
    
    # cokurtosis elements
    if (include.mom[3]) {
      for (ii in 1:p) {
        for (jj in ii:p) {
          for (kk in jj:p) {
            for (ll in kk:p) {
              c2111 <- mean(Xc2[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll])
              c1211 <- mean(Xc[, ii] * Xc2[, jj] * Xc[, kk] * Xc[, ll])
              c1121 <- mean(Xc[, ii] * Xc[, jj] * Xc2[, kk] * Xc[, ll])
              c1112 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc2[, ll])
              c0111 <- mean(Xc[, jj] * Xc[, kk] * Xc[, ll])
              c1011 <- mean(Xc[, ii] * Xc[, kk] * Xc[, ll])
              c1101 <- mean(Xc[, ii] * Xc[, jj] * Xc[, ll])
              c1110 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
              W[iter] <- mean(Xc2[, ii] * Xc2[, jj] * Xc2[, kk] * Xc2[, ll]) - mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll])^2 -
                2 * c2111 * c0111 - 2 * c1211 * c1011 - 2 * c1121 * c1101 - 2 * c1112 * c1110 +
                2 * m11[ll, ii] * c1110 * c0111 + 2 * m11[ll, jj] * c1011 * c1110 +
                2 * m11[ll, kk] * c1101 * c1110 + 2 * m11[kk, ii] * c0111 * c1101 +
                2 * m11[kk, jj] * c1011 * c1101 + 2 * m11[jj, ii] * c0111 * c1011 +
                c1110^2 * m11[ll, ll] + c1101^2 * m11[kk, kk] + c1011^2 * m11[jj, jj] + c0111^2 * m11[ii, ii]
              iter <- iter + 1
            }
          }
        }
      }
    }
    
    W <- 1 / W
  }
  
  # inverse-variance weighted - semi-full
  if (Wnum == 3) {
    W <- matrix(0, nrow = nelem, ncol = nelem)
    
    # covariance elements
    if (include.mom[1]) {
      for (ii in 1:p) {
        for (jj in ii:p) {
          iter2 <- 1
          for (uu in 1:ii) {
            for (vv in uu:p) {
              W[iter, iter2] <- W[iter2, iter] <-
                mean(Xc[, ii] * Xc[, jj] * Xc[, uu] * Xc[, vv]) - m11[ii, jj] * m11[uu, vv]
              iter2 <- iter2 + 1
            }
          }
          iter <- iter + 1
        }
      }
    }
    
    # coskewness elements
    if (include.mom[2]) {
      for (ii in 1:p) {
        for (jj in ii:p) {
          for (kk in jj:p) {
            c011 <- m11[jj, kk]
            c101 <- m11[ii, kk]
            c110 <- m11[ii, jj]
            c211 <- mean(Xc2[, ii] * Xc[, jj] * Xc[, kk])
            c121 <- mean(Xc[, ii] * Xc2[, jj] * Xc[, kk])
            c112 <- mean(Xc[, ii] * Xc[, jj] * Xc2[, kk])
            W[iter, iter] <- mean(Xc2[, ii] * Xc2[, jj] * Xc2[, kk]) - mean(Xc[, ii] * Xc[, jj] * Xc[, kk])^2 -
              2 * c011 * c211 - 2 * c101 * c121 - 2 * c110 * c112 +
              c011 * m11[ii, ii] + c101 * m11[jj, jj] + c110 * m11[kk, kk] + 6 * c011 * c101 * c110
            iter <- iter + 1
          }
        }
      }
    }
    
    # cokurtosis elements
    if (include.mom[3]) {
      for (ii in 1:p) {
        for (jj in ii:p) {
          for (kk in jj:p) {
            for (ll in kk:p) {
              c2111 <- mean(Xc2[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll])
              c1211 <- mean(Xc[, ii] * Xc2[, jj] * Xc[, kk] * Xc[, ll])
              c1121 <- mean(Xc[, ii] * Xc[, jj] * Xc2[, kk] * Xc[, ll])
              c1112 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc2[, ll])
              c0111 <- mean(Xc[, jj] * Xc[, kk] * Xc[, ll])
              c1011 <- mean(Xc[, ii] * Xc[, kk] * Xc[, ll])
              c1101 <- mean(Xc[, ii] * Xc[, jj] * Xc[, ll])
              c1110 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
              W[iter, iter] <- mean(Xc2[, ii] * Xc2[, jj] * Xc2[, kk] * Xc2[, ll]) - mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll])^2 -
                2 * c2111 * c0111 - 2 * c1211 * c1011 - 2 * c1121 * c1101 - 2 * c1112 * c1110 +
                2 * m11[ll, ii] * c1110 * c0111 + 2 * m11[ll, jj] * c1011 * c1110 +
                2 * m11[ll, kk] * c1101 * c1110 + 2 * m11[kk, ii] * c0111 * c1101 +
                2 * m11[kk, jj] * c1011 * c1101 + 2 * m11[jj, ii] * c0111 * c1011 +
                c1110^2 * m11[ll, ll] + c1101^2 * m11[kk, kk] + c1011^2 * m11[jj, jj] + c0111^2 * m11[ii, ii]
              iter <- iter + 1
            }
          }
        }
      }
    }
    
    if (n > nelem_mom[1]) {
      W <- solve(W)
    } else {
      eigW <- eigen(W, symmetric = TRUE)
      eigW$values <- sapply(eigW$values, function(a) max(c(a, 1e-7)))
      W <- eigW$vectors %*% diag(eigW$values) %*% t(eigW$vectors)
      W <- solve(W)
    }
  }
  
  # asymptotic covariance matrix as weight matrix
  if (Xi | (Wnum == 4)) {
    Xi <- matrix(0, nrow = nelem, ncol = nelem)
    
    # covariance elements
    if (include.mom[1]) {
      for (ii in 1:p) {
        for (jj in ii:p) {
          iter2 <- 1
          for (uu in 1:ii) {
            for (vv in uu:p) {
              Xi[iter, iter2] <- Xi[iter2, iter] <-
                mean(Xc[, ii] * Xc[, jj] * Xc[, uu] * Xc[, vv]) - m11[ii, jj] * m11[uu, vv]
              iter2 <- iter2 + 1
            }
          }
          iter <- iter + 1
        }
      }
    }
    
    # coskewness elements
    if (include.mom[2]) {
      # covariances with the cov elements
      if (include.mom[1]) {
        for (ii in 1:p) {
          for (jj in ii:p) {
            for (kk in jj:p) {
              iter2 <- 1
              c11100 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
              for (uu in 1:p) {
                for (vv in uu:p) {
                  Xi[iter, iter2] <- Xi[iter2, iter] <-
                    mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, uu] * Xc[, vv]) - c11100 * m11[uu, vv] -
                    mean(Xc[, ii] * Xc[, uu] * Xc[, vv]) * m11[jj, kk] -
                    mean(Xc[, jj] * Xc[, uu] * Xc[, vv]) * m11[ii, kk] -
                    mean(Xc[, kk] * Xc[, uu] * Xc[, vv]) * m11[ii, jj]
                  iter2 <- iter2 + 1
                }
              }
              iter <- iter + 1
            }
          }
        }
      }
      # covariances with the cosk elements
      if (include.mom[1]) iter2start <- nelem_mom[1] + 1 else iter2start <- 1
      iter <- iter2start
      for (ii in 1:p) {
        for (jj in ii:p) {
          for (kk in jj:p) {
            iter2 <- iter2start
            c111000 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
            for (uu in 1:ii) {
              for (vv in uu:p) {
                for (ww in vv:p) {
                  Xi[iter, iter2] <- Xi[iter2, iter] <-
                    mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, uu] * Xc[, vv] * Xc[, ww]) - c111000 * mean(Xc[, uu] * Xc[, vv] * Xc[, ww]) -
                    mean(Xc[, ii] * Xc[, uu] * Xc[, vv] * Xc[, ww]) * m11[jj, kk] - mean(Xc[, jj] * Xc[, uu] * Xc[, vv] * Xc[, ww]) * m11[ii, kk] -
                    mean(Xc[, kk] * Xc[, uu] * Xc[, vv] * Xc[, ww]) * m11[ii, jj] - mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, uu]) * m11[vv, ww] -
                    mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, vv]) * m11[uu, ww] - mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ww]) * m11[uu, vv] +
                    m11[ii, jj] * (m11[kk, uu] * m11[vv, ww] + m11[kk, vv] * m11[uu, ww] + m11[kk, ww] * m11[uu, vv]) +
                    m11[ii, kk] * (m11[jj, uu] * m11[vv, ww] + m11[jj, vv] * m11[uu, ww] + m11[jj, ww] * m11[uu, vv]) +
                    m11[jj, kk] * (m11[ii, uu] * m11[vv, ww] + m11[ii, vv] * m11[uu, ww] + m11[ii, ww] * m11[uu, vv])
                  iter2 <- iter2 + 1
                }
              }
            }
            iter <- iter + 1
          }
        }
      }
    }
    
    # cokurtosis elements
    if (include.mom[3]) {
      # covariances with the cov elements
      if (include.mom[1]) {
        for (ii in 1:p) {
          for (jj in ii:p) {
            for (kk in jj:p) {
              for (ll in kk:p) {
                iter2 <- 1
                c111100 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll])
                for (uu in 1:p) {
                  for (vv in uu:p) {
                    Xi[iter, iter2] <- Xi[iter2, iter] <-
                      mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, uu] * Xc[, vv]) - c111100 * m11[uu, vv] -
                      mean(Xc[, ii] * Xc[, uu] * Xc[, vv]) * mean(Xc[, jj] * Xc[, kk] * Xc[, ll]) -
                      mean(Xc[, jj] * Xc[, uu] * Xc[, vv]) * mean(Xc[, ii] * Xc[, kk] * Xc[, ll]) -
                      mean(Xc[, kk] * Xc[, uu] * Xc[, vv]) * mean(Xc[, ii] * Xc[, jj] * Xc[, ll]) -
                      mean(Xc[, ll] * Xc[, uu] * Xc[, vv]) * mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
                    iter2 <- iter2 + 1
                  }
                }
                iter <- iter + 1
              }
            }
          }
        }
      }
      # covariances with the cosk elements
      if (include.mom[2]) {
        if (include.mom[1]) iter2start <- nelem_mom[1] + 1 else iter2start <- 1
        iter <- iter2start + nelem_mom[2]
        for (ii in 1:p) {
          for (jj in ii:p) {
            for (kk in jj:p) {
              for (ll in kk:p) {
                iter2 <- iter2start
                c1111000 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
                c0111 <- mean(Xc[, jj] * Xc[, kk] * Xc[, ll])
                c1011 <- mean(Xc[, ii] * Xc[, kk] * Xc[, ll])
                c1101 <- mean(Xc[, ii] * Xc[, jj] * Xc[, ll])
                c1110 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
                for (uu in 1:p) {
                  for (vv in uu:p) {
                    for (ww in vv:p) {
                      Xi[iter, iter2] <- Xi[iter2, iter] <-
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, uu] * Xc[, vv] * Xc[, ww]) - c1111000 * mean(Xc[, uu] * Xc[, vv] * Xc[, ww]) -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, ii]) * c0111 -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, jj]) * c1011 -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, kk]) * c1101 -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, ll]) * c1110 -
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, uu]) * m11[vv, ww] -
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, vv]) * m11[uu, ww] -
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, ww]) * m11[uu, vv] +
                        m11[uu, vv] * (m11[ww, ii] * c0111 + m11[ww, jj] * c1011 + m11[ww, kk] * c1101 + m11[ww, ll] * c1110) +
                        m11[uu, ww] * (m11[vv, ii] * c0111 + m11[vv, jj] * c1011 + m11[vv, kk] * c1101 + m11[vv, ll] * c1110) +
                        m11[vv, ww] * (m11[uu, ii] * c0111 + m11[uu, jj] * c1011 + m11[uu, kk] * c1101 + m11[uu, ll] * c1110)
                      iter2 <- iter2 + 1
                    }
                  }
                }
                iter <- iter + 1
              }
            }
          }
        }
      }
      # covariances with the cokurt elements
      iter2start <- 1 + sum(nelem_mom[1:2] * include.mom[1:2])
      iter <- iter2start
      for (ii in 1:p) {
        for (jj in ii:p) {
          for (kk in jj:p) {
            for (ll in kk:p) {
              iter2 <- iter2start
              c1111000 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
              c0111 <- mean(Xc[, jj] * Xc[, kk] * Xc[, ll])
              c1011 <- mean(Xc[, ii] * Xc[, kk] * Xc[, ll])
              c1101 <- mean(Xc[, ii] * Xc[, jj] * Xc[, ll])
              c1110 <- mean(Xc[, ii] * Xc[, jj] * Xc[, kk])
              for (uu in 1:p) {
                for (vv in uu:p) {
                  for (ww in vv:p) {
                    for (zz in ww:p) {
                      c_u <- mean(Xc[, vv] * Xc[, ww] * Xc[, zz])
                      c_v <- mean(Xc[, uu] * Xc[, ww] * Xc[, zz])
                      c_w <- mean(Xc[, uu] * Xc[, vv] * Xc[, zz])
                      c_z <- mean(Xc[, uu] * Xc[, vv] * Xc[, ww])
                      Xi[iter, iter2] <- Xi[iter2, iter] <-
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, zz]) - 
                        c1111000 * mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, zz]) -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, zz] * Xc[, ii]) * c0111 -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, zz] * Xc[, jj]) * c1011 -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, zz] * Xc[, kk]) * c1101 -
                        mean(Xc[, uu] * Xc[, vv] * Xc[, ww] * Xc[, zz] * Xc[, ll]) * c1110 -
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, uu]) * c_u -
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, vv]) * c_v -
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, ww]) * c_w -
                        mean(Xc[, ii] * Xc[, jj] * Xc[, kk] * Xc[, ll] * Xc[, zz]) * c_z +
                        c_u * (m11[ww, ii] * c0111 + m11[ww, jj] * c1011 + m11[ww, kk] * c1101 + m11[ww, ll] * c1110) +
                        c_v * (m11[vv, ii] * c0111 + m11[vv, jj] * c1011 + m11[vv, kk] * c1101 + m11[vv, ll] * c1110) +
                        c_w * (m11[uu, ii] * c0111 + m11[uu, jj] * c1011 + m11[uu, kk] * c1101 + m11[uu, ll] * c1110) +
                        c_z * (m11[zz, ii] * c0111 + m11[zz, jj] * c1011 + m11[zz, kk] * c1101 + m11[zz, ll] * c1110)
                      iter2 <- iter2 + 1 
                    }
                  }
                }
              }
              iter <- iter + 1
            }
          }
        }
      }
    }
    
    # make PD
    eigXi <- eigen(Xi, symmetric = TRUE)
    eigXi$values <- sapply(eigXi$values, function(a) max(c(a, 1e-7)))
    Xi <- eigXi$vectors %*% diag(eigXi$values) %*% t(eigXi$vectors)
    Xi <- 0.5 * (Xi + t(Xi))
    
    if (Wnum == 4) {
      W <- solve(Xi)
      W <- 0.5 * (W + t(W))
    }
    
  } else {
    Xi <- NULL
  }
  
  return (list("W" = W, "Xi" = Xi))
}


###############################################################################
# R (http://r-project.org/) Econometrics for Performance and Risk Analysis
#
# Copyright (c) 2004-2015 Peter Carl and Brian G. Peterson and Kris Boudt
#
# This R package is distributed under the terms of the GNU Public License (GPL)
# for full details see the file COPYING
#
# $Id$
#
###############################################################################